from constants import LEVELS, COLORS, SCREEN_WIDTH, SCREEN_HEIGHT, CELL_SIZE
import pygame
import random
import sys
from agents import Agent, Snake, Rat, Bee, move_agent
from ai_systems import SimpleAI, AStarAI, QLearningAI

def initialize_level(level_num):
    try:
        level = LEVELS[level_num]
        grid_size = level["size"]
        
        if len(level["maze"]) != grid_size:
            raise ValueError(f"Level {level_num+1} has incorrect row count")
        
        grid = []
        for y, row in enumerate(level["maze"]):
            if len(row) != grid_size:
                raise ValueError(f"Level {level_num+1} row {y} has incorrect length")
            grid.append(list(row))
        
        # Validate positions
        start_x, start_y = level["start_pos"]
        if grid[start_y][start_x] == 'W':
            raise ValueError(f"Level {level_num+1} start position is a wall")
        
        exit_x, exit_y = level["exit_pos"]
        if grid[exit_y][exit_x] == 'W':
            raise ValueError(f"Level {level_num+1} exit position is a wall")
        
        return {
            "grid": grid,
            "exit_pos": level["exit_pos"],
            "rats": level["rats"],
            "start_pos": level["start_pos"],
            "size": grid_size
        }
    except IndexError:
        raise ValueError("Invalid level number")

def rat_ai(rat, grid_size, snake):
    if rat.direction is None:
        # 10% chance to move randomly
        if random.random() < 0.1:
            random_direction = random.choice(['up', 'down', 'left', 'right'])
            dx_move, dy_move = 0, 0
            if random_direction == 'up': dy_move = -1
            elif random_direction == 'down': dy_move = 1
            elif random_direction == 'left': dx_move = -1
            elif random_direction == 'right': dx_move = 1
            
            new_x = rat.x + dx_move
            new_y = rat.y + dy_move
            
            if 0 <= new_x < grid_size and 0 <= new_y < grid_size:
                if rat.grid[new_y][new_x] != 'W':
                    move_agent(rat, random_direction, grid_size)
                    return
        
        # Normal movement logic with increased speed
        dx = rat.x - snake.x
        dy = rat.y - snake.y
        
        possible_dirs = []
        if abs(dx) > abs(dy):
            possible_dirs.append('right' if dx > 0 else 'left')
            possible_dirs.append('down' if dy > 0 else 'up')
        else:
            possible_dirs.append('down' if dy > 0 else 'up')
            possible_dirs.append('right' if dx > 0 else 'left')
        
        # Add more random directions for faster movement
        possible_dirs += random.sample(['up', 'down', 'left', 'right'], 3)
        
        for direction in possible_dirs:
            dx_move, dy_move = 0, 0
            if direction == 'up': dy_move = -1
            elif direction == 'down': dy_move = 1
            elif direction == 'left': dx_move = -1
            elif direction == 'right': dx_move = 1
            
            new_x = rat.x + dx_move
            new_y = rat.y + dy_move
            
            if 0 <= new_x < grid_size and 0 <= new_y < grid_size:
                if rat.grid[new_y][new_x] != 'W':
                    move_agent(rat, direction, grid_size)
                    break

def bee_ai(bee, grid_size, snake):
    if bee.direction is None:
        # 10% chance to move randomly
        if random.random() < 0.1:
            random_direction = random.choice(['up', 'down', 'left', 'right'])
            dx_move, dy_move = 0, 0
            if random_direction == 'up': dy_move = -1
            elif random_direction == 'down': dy_move = 1
            elif random_direction == 'left': dx_move = -1
            elif random_direction == 'right': dx_move = 1
            
            new_x = bee.x + dx_move
            new_y = bee.y + dy_move
            
            if 0 <= new_x < grid_size and 0 <= new_y < grid_size:
                if bee.grid[new_y][new_x] != 'W':
                    move_agent(bee, random_direction, grid_size)
                    return
        
        # Normal movement logic with increased speed
        dx = snake.x - bee.x
        dy = snake.y - bee.y
        
        possible_dirs = []
        if abs(dx) > abs(dy):
            possible_dirs.append('right' if dx > 0 else 'left')
            possible_dirs.append('down' if dy > 0 else 'up')
        else:
            possible_dirs.append('down' if dy > 0 else 'up')
            possible_dirs.append('right' if dx > 0 else 'left')
        
        # Add more random directions for faster movement
        possible_dirs += random.sample(['up', 'down', 'left', 'right'], 3)
        
        for direction in possible_dirs:
            dx_move, dy_move = 0, 0
            if direction == 'up': dy_move = -1
            elif direction == 'down': dy_move = 1
            elif direction == 'left': dx_move = -1
            elif direction == 'right': dx_move = 1
            
            new_x = bee.x + dx_move
            new_y = bee.y + dy_move
            
            if 0 <= new_x < grid_size and 0 <= new_y < grid_size:
                if bee.grid[new_y][new_x] != 'W':
                    move_agent(bee, direction, grid_size)
                    break

def draw_health_bar(surface, snake):
    bar_width = 200
    bar_height = 20
    health_width = (snake.health / 100) * bar_width
    pygame.draw.rect(surface, COLORS["black"], (10, 10, bar_width, bar_height))
    pygame.draw.rect(surface, COLORS["health"], (10, 10, health_width, bar_height))
    font = pygame.font.Font(None, 24)
    text = font.render(f"Health: {snake.health:.1f}%", True, COLORS["white"])
    surface.blit(text, (15, 12))

def game_loop(screen, level_num, ai_mode):
    try:
        level_data = initialize_level(level_num)
    except ValueError as e:
        print(f"Level loading failed: {str(e)}")
        return

    grid = level_data["grid"]
    grid_size = level_data["size"]
    exit_pos = level_data["exit_pos"]
    start_pos = level_data["start_pos"]
    num_rats = level_data["rats"]
    cell_size = min(SCREEN_WIDTH // grid_size, SCREEN_HEIGHT // grid_size)
    
    # Initialize agents
    snake = Snake(start_pos[0], start_pos[1], grid)
    rats = [Rat(random.randint(1, grid_size-2), random.randint(1, grid_size-2), grid)
            for _ in range(num_rats)]
    bee = Bee(random.randint(1, grid_size-2), random.randint(1, grid_size-2), grid)
    
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 36)
    running = True

    # Initialize AI based on selected mode
    if ai_mode == 0:  # Simple AI
        ai = SimpleAI(grid_size)
    elif ai_mode == 1:  # A* AI
        ai = AStarAI(grid_size)
    elif ai_mode == 2:  # Q-Learning AI
        ai = QLearningAI(grid_size)
        ai.train()  # Train the Q-Learning AI before starting
    else:  # Human player
        ai = None

    while running:
        dt = clock.tick(90) / 1000  # 1.5x faster (60 FPS * 1.5 = 90)
        
        # Handle input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # AI or Human control
        if ai_mode == 3:  # Human control
            keys = pygame.key.get_pressed()
            desired_direction = None
            
            if keys[pygame.K_UP]:
                desired_direction = 'up'
            elif keys[pygame.K_DOWN]:
                desired_direction = 'down'
            elif keys[pygame.K_LEFT]:
                desired_direction = 'left'
            elif keys[pygame.K_RIGHT]:
                desired_direction = 'right'

            if desired_direction is not None:
                if (desired_direction == 'up' and snake.last_valid_direction != 'down') or \
                    (desired_direction == 'down' and snake.last_valid_direction != 'up') or \
                    (desired_direction == 'left' and snake.last_valid_direction != 'right') or \
                    (desired_direction == 'right' and snake.last_valid_direction != 'left'):
                        move_agent(snake, desired_direction, grid_size)
        elif ai is not None:  # AI control (only if AI is initialized)
            if snake.direction is None:  # Only get new move if not currently moving
                if snake.rats_caught < num_rats:  # If there are still rats to catch
                    closest_rat = min(rats, key=lambda r: abs(r.x - snake.x) + abs(r.y - snake.y)) if rats else None
                    if closest_rat:
                        direction = ai.get_move(snake, closest_rat, grid)
                        if direction:
                            move_agent(snake, direction, grid_size)
                else:  # All rats caught, move towards exit
                    exit_target = type('ExitTarget', (), {'x': exit_pos[0], 'y': exit_pos[1]})()
                    direction = ai.get_move(snake, exit_target, grid)
                    if direction:
                        move_agent(snake, direction, grid_size)

        # Update positions
        snake.update_position(dt)
        bee.update_position(dt)
        for rat in rats:
            rat.update_position(dt)
            rat_ai(rat, grid_size, snake)
        bee_ai(bee, grid_size, snake)

        # Check collisions
        rats_to_remove = []
        for i, rat in enumerate(rats):
            if (snake.x, snake.y) == (rat.x, rat.y):
                rats_to_remove.append(i)
                snake.rats_caught += 1
                snake.tail_length += 15  # Increase tail length
        for i in reversed(rats_to_remove):
            del rats[i]

        # Bee collision
        if (snake.x, snake.y) == (bee.x, bee.y):
            snake.take_damage(20)
            valid = False
            while not valid:
                new_x = random.randint(1, grid_size-2)
                new_y = random.randint(1, grid_size-2)
                if grid[new_y][new_x] != 'W':
                    valid = True
            bee.x = new_x
            bee.y = new_y
            bee.direction = None

        # Smooth rendering
        screen.fill(COLORS["black"])

        
        # Draw grid with interpolation
        for y in range(grid_size):
            for x in range(grid_size):
                base_x = x * cell_size
                base_y = y * cell_size
                
                # Wall background
                if grid[y][x] == 'W':
                    pygame.draw.rect(screen, COLORS["gray"], 
                                   (base_x, base_y, cell_size, cell_size))
                else:
                    pygame.draw.rect(screen, COLORS["black"],
                                   (base_x, base_y, cell_size, cell_size))

        # Draw exit
        exit_rect = (exit_pos[0]*cell_size, exit_pos[1]*cell_size, cell_size, cell_size)
        pygame.draw.rect(screen, COLORS["exit"], exit_rect)
        
        # Draw agents with movement interpolation
        def draw_agent(agent):
            x_pos = agent.x * cell_size
            y_pos = agent.y * cell_size
            
            if agent.direction is not None:
                progress = agent.move_progress
                dx = (agent.next_x - agent.x) * progress
                dy = (agent.next_y - agent.y) * progress
                x_pos += dx * cell_size
                y_pos += dy * cell_size
                
            pygame.draw.rect(screen, agent.color,
                           (x_pos, y_pos, cell_size, cell_size))


        # Snake Tail
        if snake.tail:
            tail_length = len(snake.tail)
            for i, segment in enumerate(snake.tail):
                # Darken each subsequent segment
                green_value = max(50, 255 - (i * 25))
                tail_color = (0, green_value, 0)
                x_pos = segment[0] * cell_size
                y_pos = segment[1] * cell_size
                pygame.draw.rect(screen, tail_color, (x_pos, y_pos, cell_size, cell_size))
        
        for rat in rats:
            draw_agent(rat)
        draw_agent(bee)
        draw_agent(snake)


        # Draw UI
        draw_health_bar(screen, snake)
        rats_text = font.render(f"Rats: {snake.rats_caught}/{num_rats}", 
                              True, COLORS["white"])
        screen.blit(rats_text, (10, 40))
        
        pygame.display.flip()

        # Win/lose conditions
        if snake.health <= 0:
            print("Game Over! Health depleted!")
            running = False
        elif (snake.x, snake.y) == exit_pos:
            if snake.rats_caught == num_rats:
                print(f"Level {level_num+1} completed!")
                running = False
            else:
                print("Exit reached but not all rats collected!")