import pygame
from ui import show_start_screen
from game_utils import game_loop
from constants import SCREEN_WIDTH, SCREEN_HEIGHT

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Maze Game")
    
    while True:
        level, ai_mode = show_start_screen(screen)  
        game_loop(screen, level-1, ai_mode)

if __name__ == "__main__":
    main()