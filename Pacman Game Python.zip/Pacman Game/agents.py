from constants import COLORS

class Agent:
    def __init__(self, x, y, grid):
        self.x = x
        self.y = y
        self.grid = grid
        self.speed = 4.5  # Increased from 3.0 (1.5x faster)
        self.move_progress = 0.0
        self.direction = None
        self.next_x = x
        self.next_y = y
        self.last_valid_direction = None

    def update_position(self, dt):
        if self.direction is not None:
            self.move_progress += self.speed * dt
            if self.move_progress >= 1.0:
                self.x = self.next_x
                self.y = self.next_y
                self.move_progress = 0.0
                self.direction = None

class Snake(Agent):
    def __init__(self, x, y, grid):
        super().__init__(x, y, grid)
        self.color = COLORS["green"]
        self.rats_caught = 0
        self.health = 100.0
        self.wall_hit_cooldown = 0.0
        self.tail_length = 15  # Initial tail length
        self.tail = []  # Start with empty list (do NOT pre-fill with duplicate positions)

    def take_damage(self, amount):
        if self.wall_hit_cooldown <= 0:
            self.health = max(0, self.health - amount)
            self.wall_hit_cooldown = 0.5  # Half-second cooldown

    def update_position(self, dt):
        # Update tail positions
        if self.direction is not None:
            self.tail.insert(0, (self.x, self.y))  # Add current position to tail
            
            # Trim the tail to match tail_length (corrected logic)
            while len(self.tail) > self.tail_length:  # <-- Change from 'if' to 'while'
                self.tail.pop()  # Remove the oldest segment until length matches

        super().update_position(dt)
        self.wall_hit_cooldown = max(0, self.wall_hit_cooldown - dt)
        
def move_agent(agent, direction, grid_size):
    if agent.direction is not None:
        return

    dx, dy = 0, 0
    if direction == 'up': dy = -1
    elif direction == 'down': dy = 1
    elif direction == 'left': dx = -1
    elif direction == 'right': dx = 1

    new_x = agent.x + dx
    new_y = agent.y + dy

    if 0 <= new_x < grid_size and 0 <= new_y < grid_size:
        if agent.grid[new_y][new_x] != 'W':
            agent.next_x = new_x
            agent.next_y = new_y
            agent.direction = direction
            agent.move_progress = 0.0
            agent.last_valid_direction = direction
        else:
            if isinstance(agent, Snake):
                agent.take_damage(10)

class Rat(Agent):
    def __init__(self, x, y, grid):
        super().__init__(x, y, grid)
        self.color = COLORS["red"]
        self.speed = 1.5

class Bee(Agent):
    def __init__(self, x, y, grid):
        super().__init__(x, y, grid)
        self.color = COLORS["blue"]
        self.speed = 2.0