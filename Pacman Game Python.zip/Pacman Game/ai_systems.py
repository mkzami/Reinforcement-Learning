import random
import numpy as np
from collections import defaultdict
import heapq

class BaseAI:
    def __init__(self, grid_size):
        self.grid_size = grid_size

    def get_move(self, agent, target, grid):
        raise NotImplementedError

class SimpleAI(BaseAI):
    """Current simple AI implementation"""
    def get_move(self, agent, target, grid):
        if agent.direction is not None:
            return None
            
        dx = target.x - agent.x
        dy = target.y - agent.y
        
        possible_dirs = []
        if abs(dx) > abs(dy):
            possible_dirs.append('right' if dx > 0 else 'left')
            possible_dirs.append('down' if dy > 0 else 'up')
        else:
            possible_dirs.append('down' if dy > 0 else 'up')
            possible_dirs.append('right' if dx > 0 else 'left')
        
        possible_dirs += ['up', 'down', 'left', 'right']
        
        for direction in possible_dirs:
            dx_move, dy_move = self._get_direction_offset(direction)
            new_x = agent.x + dx_move
            new_y = agent.y + dy_move
            
            if self._is_valid_move(new_x, new_y, grid):
                return direction
        return None

    def _get_direction_offset(self, direction):
        offsets = {
            'up': (0, -1),
            'down': (0, 1),
            'left': (-1, 0),
            'right': (1, 0)
        }
        return offsets.get(direction, (0, 0))

    def _is_valid_move(self, x, y, grid):
        return (0 <= x < self.grid_size and 
                0 <= y < self.grid_size and 
                grid[y][x] != 'W')

class AStarAI(BaseAI):
    """A* pathfinding AI implementation"""
    def get_move(self, agent, target, grid):
        if agent.direction is not None:
            return None

        path = self._find_path(
            (agent.x, agent.y),
            (target.x, target.y),
            grid
        )
        
        if path and len(path) > 1:
            next_pos = path[1]
            dx = next_pos[0] - agent.x
            dy = next_pos[1] - agent.y
            return self._get_direction(dx, dy)
        return None

    def _find_path(self, start, goal, grid):
        frontier = [(0, start)]
        came_from = {start: None}
        cost_so_far = {start: 0}
        
        while frontier:
            current = heapq.heappop(frontier)[1]
            
            if current == goal:
                break
                
            for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                next_pos = (current[0] + dx, current[1] + dy)
                
                if (0 <= next_pos[0] < self.grid_size and 
                    0 <= next_pos[1] < self.grid_size and 
                    grid[next_pos[1]][next_pos[0]] != 'W'):
                    
                    new_cost = cost_so_far[current] + 1
                    if next_pos not in cost_so_far or new_cost < cost_so_far[next_pos]:
                        cost_so_far[next_pos] = new_cost
                        priority = new_cost + self._heuristic(goal, next_pos)
                        heapq.heappush(frontier, (priority, next_pos))
                        came_from[next_pos] = current
        
        return self._reconstruct_path(came_from, start, goal)

    def _heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def _reconstruct_path(self, came_from, start, goal):
        current = goal
        path = []
        
        while current is not None:
            path.append(current)
            current = came_from.get(current)
            
        path.reverse()
        return path if path[0] == start else []

    def _get_direction(self, dx, dy):
        if dx > 0: return 'right'
        if dx < 0: return 'left'
        if dy > 0: return 'down'
        if dy < 0: return 'up'
        return None

class QLearningAI(BaseAI):
    """Approximate Q-Learning AI using function approximation instead of a Q-table"""
    def __init__(self, grid_size, learning_rate=0.1, discount_factor=0.9, epsilon=0.1):
        super().__init__(grid_size)
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.epsilon = epsilon  # Exploration rate
        self.grid_memory = None
        self.training_episodes = 0
        self.step_punishment = -0.5  # Constant punishment for each step
        
        # Initialize weights for each feature and action
        self.weights = {
            'up': np.zeros(8),
            'down': np.zeros(8),
            'left': np.zeros(8),
            'right': np.zeros(8)
        }

    def get_move(self, agent, target, grid):
        if agent.direction is not None:
            return None
            
        # Store grid for future reference
        if self.grid_memory is None:
            self.grid_memory = [row[:] for row in grid]
            
        # Decide between exploration and exploitation
        if random.random() < self.epsilon:
            # Exploration: choose random valid action using a smarter strategy
            return self._smart_explore(agent, target, grid)
        else:
            # Exploitation: choose best action
            return self.get_best_action(agent, target, grid)
    
    def _smart_explore(self, agent, target, grid):
        """Smarter exploration that favors actions that might lead to target"""
        valid_actions = self.get_valid_actions(agent, grid)
        if not valid_actions:
            return None
            
        # Calculate direction to target
        dx = target.x - agent.x
        dy = target.y - agent.y
        
        # Assign higher probability to actions that move toward target
        probs = []
        for action in valid_actions:
            prob = 1.0  # Base probability
            if (dx > 0 and action == 'right') or (dx < 0 and action == 'left'):
                prob += 1.0
            if (dy > 0 and action == 'down') or (dy < 0 and action == 'up'):
                prob += 1.0
            probs.append(prob)
            
        # Normalize probabilities
        total = sum(probs)
        probs = [p/total for p in probs]
        
        # Choose action based on weighted probability
        return np.random.choice(valid_actions, p=probs)
    
    def get_valid_actions(self, agent, grid):
        """Get list of valid actions from current position"""
        valid_actions = []
        directions = ['up', 'down', 'left', 'right']
        
        for direction in directions:
            dx, dy = self._get_direction_offset(direction)
            new_x, new_y = agent.x + dx, agent.y + dy
            
            if self._is_valid_move(new_x, new_y, grid):
                valid_actions.append(direction)
                
        return valid_actions
    
    def get_best_action(self, agent, target, grid):
        """Choose the best action based on approximated Q-values and valid moves"""
        valid_actions = self.get_valid_actions(agent, grid)
        
        if not valid_actions:
            return None
        
        # Extract features
        features = self._extract_features(agent, target, grid)
        
        # Calculate Q-value for each valid action
        q_values = {}
        for action in valid_actions:
            q_values[action] = np.dot(self.weights[action], features)
        
        # If all values are very close, choose randomly
        if max(q_values.values()) - min(q_values.values()) < 0.1:
            return random.choice(valid_actions)
            
        # Otherwise choose the action with highest Q-value
        return max(q_values.items(), key=lambda x: x[1])[0]

    def train(self, episodes=10000):
        print(f"Training Approximate Q-Learning AI with {episodes} episodes...")
        self.training_episodes = episodes
        
        # Generate a simple maze for training if we don't have one yet
        if self.grid_memory is None:
            self.grid_memory = self._generate_training_grid()
        
        # Initialize experience replay memory
        experience_memory = []
        memory_size = 10000
        batch_size = 64
            
        for episode in range(episodes):
            if episode % 1000 == 0:
                print(f"Episode {episode}/{episodes}")
                # Decrease exploration rate over time
                self.epsilon = max(0.01, self.epsilon * 0.99)
            
            # Reset for new episode
            agent_pos = (random.randint(1, self.grid_size-2), random.randint(1, self.grid_size-2))
            while self.grid_memory[agent_pos[1]][agent_pos[0]] == 'W':
                agent_pos = (random.randint(1, self.grid_size-2), random.randint(1, self.grid_size-2))
                
            target_pos = (random.randint(1, self.grid_size-2), random.randint(1, self.grid_size-2))
            while self.grid_memory[target_pos[1]][target_pos[0]] == 'W' or agent_pos == target_pos:
                target_pos = (random.randint(1, self.grid_size-2), random.randint(1, self.grid_size-2))
            
            # Run one episode
            episode_experiences = self._train_episode(agent_pos, target_pos, 200)  # Max 200 steps per episode
            
            # Add episode experiences to memory
            experience_memory.extend(episode_experiences)
            if len(experience_memory) > memory_size:
                experience_memory = experience_memory[-memory_size:]
                
            # Experience replay - learn from random samples of past experiences
            if len(experience_memory) >= batch_size:
                batch = random.sample(experience_memory, batch_size)
                for experience in batch:
                    self._update_weights(*experience)
        
        print("Approximate Q-Learning training complete.")
    
    def _train_episode(self, agent_pos, target_pos, max_steps):
        """Run a single training episode, return experiences"""
        x, y = agent_pos
        target_x, target_y = target_pos
        experiences = []
        
        for step in range(max_steps):
            # Create a mock agent and target for feature extraction
            mock_agent = type('obj', (object,), {'x': x, 'y': y})
            mock_target = type('obj', (object,), {'x': target_x, 'y': target_y})
            
            # Get current features
            features = self._extract_features(mock_agent, mock_target, self.grid_memory)
            
            # Select action (epsilon-greedy)
            valid_actions = []
            for direction in ['up', 'down', 'left', 'right']:
                dx, dy = self._get_direction_offset(direction)
                new_x, new_y = x + dx, y + dy
                
                if 0 <= new_x < self.grid_size and 0 <= new_y < self.grid_size and self.grid_memory[new_y][new_x] != 'W':
                    valid_actions.append(direction)
            
            if not valid_actions:
                break  # No valid moves
                
            # Either explore or exploit
            if random.random() < self.epsilon:
                # Smart exploration
                probs = []
                for action in valid_actions:
                    prob = 1.0  # Base probability
                    if (target_x - x > 0 and action == 'right') or (target_x - x < 0 and action == 'left'):
                        prob += 1.0
                    if (target_y - y > 0 and action == 'down') or (target_y - y < 0 and action == 'up'):
                        prob += 1.0
                    probs.append(prob)
                
                total = sum(probs)
                probs = [p/total for p in probs]
                
                action = np.random.choice(valid_actions, p=probs)
            else:
                # Get Q-values for all valid actions
                q_values = {}
                for a in valid_actions:
                    q_values[a] = np.dot(self.weights[a], features)
                
                if len(set(q_values.values())) <= 1:  # All equal
                    action = random.choice(valid_actions)
                else:
                    action = max(q_values.items(), key=lambda x: x[1])[0]
            
            # Take action
            dx, dy = self._get_direction_offset(action)
            new_x, new_y = x + dx, y + dy
            
            # Calculate reward (including constant punishment)
            reward = self._calculate_reward(new_x, new_y, target_x, target_y)
            
            # Move agent
            x, y = new_x, new_y
            
            # Get new features
            mock_agent.x, mock_agent.y = x, y
            new_features = self._extract_features(mock_agent, mock_target, self.grid_memory)
            
            # Store experience for later batch updating
            experiences.append((features, action, reward, new_features, valid_actions))
            
            # Check if we've reached the target
            if (x, y) == (target_x, target_y):
                break
                
        return experiences
    
    def _extract_features(self, agent, target, grid):
        """Extract features for function approximation"""
        features = np.zeros(8)
        
        # Feature 1-2: Normalized direction to target
        dx = target.x - agent.x
        dy = target.y - agent.y
        distance = max(1, abs(dx) + abs(dy))  # Manhattan distance
        features[0] = dx / distance  # Normalized x direction
        features[1] = dy / distance  # Normalized y direction
        
        # Feature 3: Inverse distance to target (closer = higher value)
        features[2] = 1.0 / distance
        
        # Features 4-7: Walls in adjacent cells (0=open, 1=wall)
        directions = ['up', 'right', 'down', 'left']
        for i, direction in enumerate(directions):
            dx_move, dy_move = self._get_direction_offset(direction)
            new_x = agent.x + dx_move
            new_y = agent.y + dy_move
            
            if not (0 <= new_x < self.grid_size and 
                    0 <= new_y < self.grid_size and 
                    grid[new_y][new_x] != 'W'):
                features[3+i] = 1.0
        
        # Feature 8: Bias term
        features[7] = 1.0
        
        return features
    
    def _calculate_reward(self, x, y, target_x, target_y):
        """Calculate reward for a given position"""
        # Constant punishment per step
        step_reward = self.step_punishment
        
        if (x, y) == (target_x, target_y):
            return 100.0  # Large reward for reaching target
        
        # Calculate current and previous Manhattan distance
        current_distance = abs(x - target_x) + abs(y - target_y)
        
        # Distance-based reward component
        distance_reward = 10.0 / (current_distance + 1)
        
        return step_reward + distance_reward
    
    def _update_weights(self, features, action, reward, new_features, valid_next_actions):
        """Update weights using Q-learning with function approximation"""
        # Calculate current Q-value
        current_q = np.dot(self.weights[action], features)
        
        # Find max Q-value for next state
        next_q_values = []
        for next_action in valid_next_actions:
            next_q_values.append(np.dot(self.weights[next_action], new_features))
            
        max_next_q = max(next_q_values) if next_q_values else 0
        
        # Calculate target Q-value
        target_q = reward + self.discount_factor * max_next_q
        
        # Calculate error
        error = target_q - current_q
        
        # Update weights for chosen action
        self.weights[action] += self.learning_rate * error * features
    
    def _generate_training_grid(self):
        """Generate a simple grid for training"""
        grid = [['.' for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        
        # Add border walls
        for i in range(self.grid_size):
            grid[0][i] = 'W'
            grid[self.grid_size-1][i] = 'W'
            grid[i][0] = 'W'
            grid[i][self.grid_size-1] = 'W'
        
        # Add some random walls
        wall_count = self.grid_size * 3  # Adjust based on grid size
        for _ in range(wall_count):
            x = random.randint(2, self.grid_size-3)
            y = random.randint(2, self.grid_size-3)
            grid[y][x] = 'W'
        
        return grid
    
    def _get_direction_offset(self, direction):
        """Get X,Y offset for a direction"""
        offsets = {
            'up': (0, -1),
            'down': (0, 1),
            'left': (-1, 0),
            'right': (1, 0)
        }
        return offsets.get(direction, (0, 0))

    def _is_valid_move(self, x, y, grid):
        """Check if a move is valid"""
        return (0 <= x < self.grid_size and 
                0 <= y < self.grid_size and 
                grid[y][x] != 'W') 