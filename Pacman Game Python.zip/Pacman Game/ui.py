import pygame
import sys
import os
from constants import COLORS, SCREEN_WIDTH, SCREEN_HEIGHT

class Button:
    def __init__(self, text, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = COLORS["button"]
        self.hover_color = COLORS["button_hover"]
        self.current_color = self.color
        
    def draw(self, surface, font):
        pygame.draw.rect(surface, self.current_color, self.rect)
        text_surf = font.render(self.text, True, COLORS["white"])
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

def load_background():
    """Load the background image from the root folder."""
    bg_path = os.path.join(os.path.dirname(__file__), "background.png")
    print("Trying to load background from:", bg_path)

    if os.path.exists(bg_path):
        try:
            bg_image = pygame.image.load(bg_path)
            bg_image = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
            return bg_image
        except pygame.error as e:
            print(f"Error loading background image: {e}")
            return None
    else:
        print("Warning: Background image not found at", bg_path)
        return None

def show_ai_selection(screen):
    # Load background image
    bg_image = load_background()
    
    font = pygame.font.Font(None, 32)
    title_text = font.render("Select AI Mode", True, COLORS["white"])
    title_rect = title_text.get_rect(center=(SCREEN_WIDTH//2, 100))
    
    ai_buttons = [
        Button("Simple AI", 300, 250, 200, 50),
        Button("A* Pathfinding", 300, 320, 200, 50),
        Button("Q-Learning", 300, 390, 200, 50),
        Button("Human Player", 300, 460, 200, 50)
    ]
    
    while True:
        mouse_pos = pygame.mouse.get_pos()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i, button in enumerate(ai_buttons):
                    if button.rect.collidepoint(mouse_pos):
                        return i # Returns 0=Simple, 1=A*, 2=Q-Learning, 3=Human
        
        # Draw background
        if bg_image:
            screen.blit(bg_image, (0, 0))
        else:
            screen.fill(COLORS["black"])
        
        # Create a semi-transparent overlay for better text readability
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))  # Black with 50% transparency
        screen.blit(overlay, (0, 0))
        
        for button in ai_buttons:
            button.current_color = button.hover_color if button.rect.collidepoint(mouse_pos) else button.color
        
        screen.blit(title_text, title_rect)
        for button in ai_buttons:
            button.draw(screen, font)
        
        pygame.display.flip()

def show_start_screen(screen):
    ai_mode = show_ai_selection(screen)
    
    # Load background image
    bg_image = load_background()
    
    title_font = pygame.font.Font(None, 48)
    button_font = pygame.font.Font(None, 32)
    title_text = title_font.render("A Game of Python", True, COLORS["green"])
    title_rect = title_text.get_rect(center=(SCREEN_WIDTH//2, 100))
    
    buttons = [Button(f"Level {i+1}", 300, 200 + i*70, 200, 50) for i in range(5)]
    
    while True:
        mouse_pos = pygame.mouse.get_pos()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i, button in enumerate(buttons):
                    if button.rect.collidepoint(mouse_pos):
                        return i + 1, ai_mode
        
        # Draw background
        if bg_image:
            screen.blit(bg_image, (0, 0))
        else:
            screen.fill(COLORS["black"])
        
        # Create a semi-transparent overlay for better text readability
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))  # Black with 50% transparency
        screen.blit(overlay, (0, 0))
        
        for button in buttons:
            button.current_color = button.hover_color if button.rect.collidepoint(mouse_pos) else button.color
        
        screen.blit(title_text, title_rect)
        for button in buttons:
            button.draw(screen, button_font)
        
        pygame.display.flip()